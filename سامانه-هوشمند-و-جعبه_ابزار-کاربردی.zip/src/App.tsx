/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShopHeader } from './components/ShopHeader.tsx';
import { ProductCard, ViewLayout } from './components/ProductCard.tsx';
import { ProductDetailModal } from './components/ProductDetailModal.tsx';
import { AddProductModal } from './components/AddProductModal.tsx';
import { SchedulerModal } from './components/SchedulerModal.tsx';
import { ProductItem, SchedulerInfo } from './types.ts';
import {
  Search,
  Plus,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Package,
  LayoutGrid,
  Grid3X3,
  List,
  Grid2X2,
  Columns2,
  Layers,
} from 'lucide-react';
import { toPersianDigits, formatPersianNumber, getCurrentPersianDate } from './utils/jalali.ts';

export default function App() {
  const [products, setProducts] = useState<ProductItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);

  // View Layout mode: grid-4 | grid-3 | list | compact | large
  const [layout, setLayout] = useState<ViewLayout>(() => {
    const saved = localStorage.getItem('shop_preferred_layout');
    return (saved as ViewLayout) || 'grid-4';
  });

  const handleLayoutChange = (newLayout: ViewLayout) => {
    setLayout(newLayout);
    localStorage.setItem('shop_preferred_layout', newLayout);
  };

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isSchedulerModalOpen, setIsSchedulerModalOpen] = useState(false);

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Scheduler Info
  const [schedulerInfo, setSchedulerInfo] = useState<SchedulerInfo | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch products with localStorage persistence priority (preserves user adds/deletes on refresh)
  const fetchProducts = async () => {
    try {
      setLoading(true);

      // 1. If user has already visited or customized their shop, ALWAYS load from localStorage
      const cached = localStorage.getItem('shop_saved_products');
      if (cached !== null) {
        try {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed)) {
            setProducts(parsed);
            return;
          }
        } catch {
          // ignore corrupted JSON and fallback
        }
      }

      // 2. Only on very first initial visit (when localStorage is empty), seed from server/defaults
      const res = await fetch('/api/products');
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const json = await res.json();
        if (json.success && Array.isArray(json.products) && json.products.length > 0) {
          setProducts(json.products);
          localStorage.setItem('shop_saved_products', JSON.stringify(json.products));
          return;
        }
      }
    } catch (err) {
      console.warn('API /api/products fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch scheduler info
  const fetchScheduler = async () => {
    try {
      const res = await fetch('/api/scheduler/status');
      const json = await res.json();
      if (json.success) {
        setSchedulerInfo(json);
      }
    } catch (err) {
      console.error('Failed to load scheduler', err);
    }
  };

  useEffect(() => {
    fetchProducts();
    fetchScheduler();
    const interval = setInterval(fetchScheduler, 60000);
    return () => clearInterval(interval);
  }, []);

  // Handle Refresh All Prices
  const handleRefreshAll = async () => {
    try {
      setIsRefreshing(true);
      const res = await fetch('/api/products/refresh-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isScheduled: false }),
      });
      const json = await res.json();
      if (json.success && json.products) {
        setProducts(json.products);
        localStorage.setItem('shop_saved_products', JSON.stringify(json.products));
        if (selectedProduct) {
          const updated = json.products.find((p: ProductItem) => p.id === selectedProduct.id);
          if (updated) setSelectedProduct(updated);
        }
        showToast(json.message || 'قیمت‌های تمام کالاها با موفقیت استعلام و بروزرسانی شدند');
      }
    } catch (err) {
      console.error('Refresh failed', err);
      showToast('خطا در استعلام گروهی قیمت‌ها');
    } finally {
      setIsRefreshing(false);
    }
  };

  // Handle Refresh Single Product from Detail Page
  const handleRefreshSingle = async (productId: string) => {
    try {
      setIsRefreshing(true);
      const res = await fetch(`/api/products/${productId}/sync`, {
        method: 'POST',
      });
      const json = await res.json();
      if (json.success && json.product) {
        setProducts((prev) => {
          const updated = prev.map((p) => (p.id === productId ? json.product : p));
          localStorage.setItem('shop_saved_products', JSON.stringify(updated));
          return updated;
        });
        setSelectedProduct(json.product);
        showToast(json.message || 'قیمت کالا با موفقیت بروز شد');
      }
    } catch (err) {
      console.error('Single refresh failed', err);
      showToast('خطا در استعلام قیمت کالا');
    } finally {
      setIsRefreshing(false);
    }
  };

  // Delete product
  const handleDeleteProduct = async () => {
    if (!deleteTarget) return;
    try {
      const res = await fetch(`/api/products/${deleteTarget.id}`, {
        method: 'DELETE',
      });
      const json = await res.json();
      // Remove product locally
      const updated = products.filter((p) => p.id !== deleteTarget.id);
      setProducts(updated);
      localStorage.setItem('shop_saved_products', JSON.stringify(updated));
      if (selectedProduct?.id === deleteTarget.id) {
        setSelectedProduct(null);
      }
      showToast(`کالای «${deleteTarget.name}» حذف شد`);
    } catch (err) {
      console.error('Failed to delete product', err);
      // Fallback local deletion
      const updated = products.filter((p) => p.id !== deleteTarget.id);
      setProducts(updated);
      localStorage.setItem('shop_saved_products', JSON.stringify(updated));
      showToast(`کالای «${deleteTarget.name}» از لیست حذف شد`);
    } finally {
      setDeleteTarget(null);
    }
  };

  // Product added callback
  const handleProductAdded = (newProduct: ProductItem) => {
    const updated = [newProduct, ...products];
    setProducts(updated);
    localStorage.setItem('shop_saved_products', JSON.stringify(updated));
    showToast(`کالای جدید با قیمت استعلام‌شده اضافه شد`);
  };

  // Categories list
  const categories = [
    { id: 'all', label: 'همه محصولات' },
    { id: 'لپ‌تاپ و اولترابوک', label: 'لپ‌تاپ و اولترابوک' },
    { id: 'لوازم جانبی و گیمینگ', label: 'لوازم جانبی و ماوس' },
    { id: 'قطعات و ارتقا سیستم', label: 'قطعات و SSD' },
    { id: 'مانیتور و نمایشگر', label: 'مانیتور' },
  ];

  // Filtered Products
  const filteredProducts = products.filter((prod) => {
    const matchSearch =
      prod.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prod.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat = selectedCategory === 'all' || prod.category === selectedCategory;
    return matchSearch && matchCat;
  });

  // View layout definitions with icons and descriptions
  const layoutOptions: { id: ViewLayout; label: string; icon: React.FC<{ className?: string }>; desc: string }[] = [
    { id: 'grid-4', label: '۴ در سطر', icon: LayoutGrid, desc: 'چیدمان ۴ ستونه متراکم و مدرن' },
    { id: 'grid-3', label: '۳ در سطر', icon: Grid3X3, desc: 'چیدمان ۳ ستونه استاندارد' },
    { id: 'list', label: 'خطی / سطری', icon: List, desc: 'نمایش افقی و سطری کالاها' },
    { id: 'compact', label: 'کوچک و فشرده', icon: Grid2X2, desc: 'کارت‌های مینیاتوری برای پایش سریع' },
    { id: 'large', label: 'بزرگ با جزئیات', icon: Columns2, desc: '۲ در سطر با عکس‌های درشت' },
  ];

  const getGridContainerClass = (currentLayout: ViewLayout) => {
    switch (currentLayout) {
      case 'grid-4':
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4';
      case 'grid-3':
        return 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5';
      case 'list':
        return 'flex flex-col gap-3';
      case 'compact':
        return 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3';
      case 'large':
        return 'grid grid-cols-1 md:grid-cols-2 gap-6';
      default:
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Top Header */}
      <ShopHeader
        schedulerInfo={schedulerInfo}
        onRefreshAll={handleRefreshAll}
        isRefreshing={isRefreshing}
        onOpenAddModal={() => setIsAddModalOpen(true)}
        onOpenSchedulerModal={() => setIsSchedulerModalOpen(true)}
        productsCount={products.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {selectedProduct ? (
          /* Dedicated Product Detailed Page */
          <ProductDetailModal
            product={selectedProduct}
            onBack={() => setSelectedProduct(null)}
            onRefreshSingle={handleRefreshSingle}
            isRefreshingSingle={isRefreshing}
          />
        ) : (
          /* Dashboard & Product Grid View */
          <div className="space-y-5">
            {/* Search & Filter Bar */}
            <div className="rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-md flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute top-3.5 right-3.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="جستجو در میان کالاها، لپ‌تاپ‌ها، قطعات، ماوس و مانیتور..."
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 pr-10 pl-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Category Filter Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setSelectedCategory(c.id)}
                    className={`whitespace-nowrap px-3 py-2 rounded-xl text-xs font-semibold transition ${
                      selectedCategory === c.id
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Layout Switcher & Status Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800/80">
              {/* Product Counter / Summary */}
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Layers className="w-4 h-4 text-indigo-400" />
                <span>
                  نمایش <strong className="text-white font-mono">{toPersianDigits(filteredProducts.length)}</strong> کالا از مجموع <strong className="text-slate-300 font-mono">{toPersianDigits(products.length)}</strong>
                </span>
              </div>

              {/* Layout Switcher Segmented Control */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto overflow-x-auto max-w-full">
                <span className="text-[11px] text-slate-400 font-medium px-2 hidden lg:inline">
                  حالت نمایش:
                </span>
                {layoutOptions.map((opt) => {
                  const Icon = opt.icon;
                  const isActive = layout === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleLayoutChange(opt.id)}
                      title={opt.desc}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition active:scale-95 whitespace-nowrap ${
                        isActive
                          ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30 font-bold'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{opt.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Product Cards Container */}
            {loading ? (
              <div className="py-20 text-center text-slate-400 text-sm">
                در حال بارگذاری لیست کالاهای مغازه...
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="py-20 text-center rounded-3xl bg-slate-900 border border-slate-800 p-8 space-y-3">
                <Package className="w-12 h-12 text-slate-600 mx-auto" />
                <h3 className="text-base font-bold text-white">کالایی یافت نشد</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  با استفاده از دکمه «افزودن کالا و لینک»، کالای جدید خود را به همراه لینک دیجی‌کالا
                  وارد کنید تا استعلام آغاز شود.
                </p>
                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold transition"
                >
                  <Plus className="w-4 h-4" />
                  <span>معرفی کالای اول</span>
                </button>
              </div>
            ) : (
              <div className={getGridContainerClass(layout)}>
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    layout={layout}
                    onSelect={(p) => setSelectedProduct(p)}
                    onDelete={(id, name) => setDeleteTarget({ id, name })}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/60 bg-slate-950 py-4 text-center text-xs text-slate-500">
        سیستم هوشمند پایش و استعلام آنلاین قیمت کالاها از دیجی‌کالا · ذخیره‌سازی محلی نوسانات بازار
      </footer>

      {/* MODALS */}
      {/* 1. Add Product Modal */}
      {isAddModalOpen && (
        <AddProductModal
          onClose={() => setIsAddModalOpen(false)}
          onProductAdded={handleProductAdded}
        />
      )}

      {/* 2. Scheduler Settings Modal */}
      {isSchedulerModalOpen && (
        <SchedulerModal
          schedulerInfo={schedulerInfo}
          onRefreshAll={handleRefreshAll}
          isRefreshing={isRefreshing}
          onClose={() => setIsSchedulerModalOpen(false)}
        />
      )}

      {/* 3. Delete Confirmation Dialog */}
      {deleteTarget && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
        >
          <div className="bg-slate-900 border border-rose-900/60 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-950 text-rose-400 flex items-center justify-center border border-rose-800/60">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="font-bold text-white text-base">
              حذف دائمی کالا و پوشه نوسانات قیمتی؟
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              آیا از حذف کامل کالای «<strong>{deleteTarget.name}</strong>» اطمینان دارید؟
              <br />
              طبق ساختار درخواستی، پوشه ذخیره‌سازی این کالا و تمامی سوابق قیمتی آن به طور کامل پاک
              خواهد شد.
            </p>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-semibold transition"
              >
                انصراف
              </button>
              <button
                type="button"
                onClick={handleDeleteProduct}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-950/40 transition active:scale-95"
              >
                بله، پوشه و کالا حذف شود
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-900 border border-indigo-500 text-white text-xs font-semibold shadow-2xl animate-in slide-in-from-bottom duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
