export interface ProductItem {
  id: string;
  name: string;
  category: string;
  sourceUrl: string;
  imageUrl: string;
  currentPriceToman: number;
  lastPriceToman: number;
  shopCostToman?: number;
  marginPercent: number;
  customerQuoteToman: number;
  stockStatus: 'in_stock' | 'out_of_stock' | 'call';
  warranty: string;
  lastRefreshedAt: string;
  createdAt: string;
  notes: string;
}

export interface PriceHistoryItem {
  timestamp: string;
  jalaliDate: string;
  jalaliTime: string;
  priceToman: number;
  customerQuoteToman: number;
  source: string;
  changePercent?: number;
}

export interface SchedulerInfo {
  nextScheduledTime: string;
  remainingMinutes: number;
  lastAutoSyncTime: string | null;
  fixedScheduleHours: number[];
}
