import React from 'react';
import {
  RotateCcw,
  Plus,
  Clock,
  Laptop,
} from 'lucide-react';
import { toPersianDigits } from '../utils/jalali.ts';
import { SchedulerInfo } from '../types.ts';

interface ShopHeaderProps {
  schedulerInfo: SchedulerInfo | null;
  onRefreshAll: () => void;
  isRefreshing: boolean;
  onOpenAddModal: () => void;
  onOpenSchedulerModal: () => void;
  productsCount: number;
}

export const ShopHeader: React.FC<ShopHeaderProps> = ({
  schedulerInfo,
  onRefreshAll,
  isRefreshing,
  onOpenAddModal,
  onOpenSchedulerModal,
  productsCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between py-3.5 gap-4">
          {/* Shop Title & Badge */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-500 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Laptop className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                  سیستم استعلام و پایش قیمت فروشگاه کامپیوتر
                </h1>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-medium border border-emerald-800/60 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{toPersianDigits(productsCount)} کالا فعال</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                پایش زنده قیمت اصلی دیجی‌کالا و ثبت تاریخچه نوسانات بازار
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Next 3-hour sync badge */}
            <button
              onClick={onOpenSchedulerModal}
              title="مشاهده زمان‌بندی پایش خودکار ۳ ساعته"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800/90 text-slate-300 text-xs border border-slate-800 hover:border-slate-700 transition"
            >
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>پایش ۳ ساعته بعدی:</span>
              <span className="font-semibold text-white">
                {schedulerInfo?.nextScheduledTime || 'ساعت ۱۲:۰۰'}
              </span>
            </button>

            {/* Manual Refresh All Button */}
            <button
              onClick={onRefreshAll}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600/90 hover:bg-indigo-600 disabled:opacity-50 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition active:scale-95"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'در حال استعلام...' : 'بروزرسانی قیمت‌ها'}</span>
            </button>

            {/* Add New Product Button */}
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-md shadow-emerald-600/20 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>افزودن کالا و لینک</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
