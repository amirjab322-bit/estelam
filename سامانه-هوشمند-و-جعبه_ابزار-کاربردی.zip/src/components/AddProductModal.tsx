import React, { useState } from 'react';
import {
  X,
  Link as LinkIcon,
  Search,
  Sparkles,
  Percent,
  Check,
  Image as ImageIcon,
  Code2,
  AlertCircle,
  Zap,
  Tag,
  Activity,
  Wifi,
} from 'lucide-react';
import { formatPersianNumber, toPersianDigits, toEnglishDigits } from '../utils/jalali.ts';
import { extractPriceFromDigikalaInspect } from '../utils/digikalaScraper.ts';
import { extractDkpId } from '../utils/universalScraper.ts';

interface AddProductModalProps {
  onClose: () => void;
  onProductAdded: (newProd: any) => void;
}

export const AddProductModal: React.FC<AddProductModalProps> = ({
  onClose,
  onProductAdded,
}) => {
  const [url, setUrl] = useState('');
  const [inspectSnippet, setInspectSnippet] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractSuccessMsg, setExtractSuccessMsg] = useState<string | null>(null);
  const [extractErrorMsg, setExtractErrorMsg] = useState<string | null>(null);
  const [discountInfo, setDiscountInfo] = useState<{
    hasDiscount: boolean;
    discountedPrice?: number;
    discountPercent?: string;
  } | null>(null);
  const [autoFilled, setAutoFilled] = useState(false);
  const [serverStatus, setServerStatus] = useState<{ checked: boolean; isOnline: boolean; text: string } | null>(null);
  const [isCheckingServer, setIsCheckingServer] = useState(false);

  const checkServerHealth = async () => {
    try {
      setIsCheckingServer(true);
      let res = await fetch('/api/track-url');
      if (res.status === 404) {
        // Fallback for edge workers that expect POST method
        res = await fetch('/api/track-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ping: true }),
        });
      }

      if (res.ok || res.status === 400) {
        const json = await res.json().catch(() => ({}));
        setServerStatus({
          checked: true,
          isOnline: true,
          text: json.message || 'سرور استعلام ورکر با موفقیت پاسخ داد و آنلاین است',
        });
      } else {
        setServerStatus({
          checked: true,
          isOnline: false,
          text: `پاسخ با کد وضعیت ${res.status}`,
        });
      }
    } catch (e: any) {
      setServerStatus({
        checked: true,
        isOnline: false,
        text: `عدم ارتباط با سرور (${e.message || 'Network Error'})`,
      });
    } finally {
      setIsCheckingServer(false);
    }
  };

  // Form fields
  const [name, setName] = useState('');
  const [category, setCategory] = useState('لوازم جانبی و قطعات');
  const [priceToman, setPriceToman] = useState<number>(0);
  const [marginPercent, setMarginPercent] = useState<number>(10);
  const [imageUrl, setImageUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live calculation of shop selling price based on profit margin %
  const customerSellingPrice =
    priceToman > 0
      ? Math.round((priceToman * (1 + (Number(marginPercent) || 0) / 100)) / 1000) * 1000
      : 0;
  const profitAmountToman = customerSellingPrice > 0 ? customerSellingPrice - priceToman : 0;

  // Quick preset links for easy testing (including user's laptop and discounted product)
  const sampleLinks = [
    {
      title: 'لپ‌تاپ لنوو IdeaPad 1 (قیمت واقعی ۸۹.۴ میلیون)',
      url: 'https://www.digikala.com/product/dkp-18991772/%D9%84%D9%BE%D8%AA%D8%A7%D9%BE-%D9%84%D9%86%D9%88%D9%88-%D9%85%D8%AF%D9%84-ideapad-1-15ijl7-%D8%A8%D8%A7-%D9%BE%D8%B1%D8%AF%D8%A7%D8%B2%D9%86%D8%AF%D9%87-celeron-n4500-%D8%B1%D9%85-ddr4-8gb-%D8%A8%D8%A7-%D9%81%D8%B1%DA%A9%D8%A7%D9%86%D8%B3-2933mhz-%D8%AD%D8%A7%D9%81%D8%B8%D9%87-ssd-%D8%A8%D8%A7-%D8%B8%D8%B1%D9%81%DB%8C%D8%AA-256gb-%D9%86%D9%85%D8%A7%DB%8C%D8%B4%DA%AF%D8%B1-156-%D8%A7%DB%8C%D9%86%DA%86-tn-%D8%A8%D8%A7-%D9%88%D8%B6%D9%88%D8%AD-full-hd/?product_id=18991772&variant_id=70776246',
    },
    {
      title: 'ماوس T2 گیمینگ (کالای تخفیف‌دار دیجی‌کالا)',
      url: 'https://www.digikala.com/product/dkp-20717228/%D9%85%D8%A7%D9%88%D8%B3-%D8%A8%DB%8C-%D8%B3%DB%8C%D9%85-%DA%AF%DB%8C%D9%85%DB%8C%D9%86%DA%AF-%D9%85%D8%AF%D9%84-t2/?ad_variant_id=73538348',
    },
    {
      title: 'ماوس بی سیم تسکو TM 795W',
      url: 'https://www.digikala.com/product/dkp-19769009/',
    },
    {
      title: 'لپ‌تاپ ایسوس TUF F15',
      url: 'https://www.digikala.com/product/dkp-13840212/asus-tuf-gaming-f15-fx507/',
    },
    {
      title: 'اس‌اس‌دی سامسونگ 980 پرو',
      url: 'https://www.digikala.com/product/dkp-4820194/samsung-980-pro-nvme-1tb/',
    },
  ];

  // Live parser for pasted inspect code / price
  const handleInspectSnippetChange = (val: string) => {
    setInspectSnippet(val);
    if (!val.trim()) return;

    const parsed = extractPriceFromDigikalaInspect(val);
    if (parsed && parsed.priceToman > 0) {
      setPriceToman(parsed.priceToman);
      setAutoFilled(true);
      if (parsed.isDiscountedOriginal) {
        setDiscountInfo({ hasDiscount: true });
        setExtractSuccessMsg(
          `قیمت اصلی و بدون تخفیف (${formatPersianNumber(parsed.priceToman)} تومان) از کد اینسپکت [${parsed.sourceType}] استخراج و درج شد.`
        );
      } else {
        setDiscountInfo(null);
        setExtractSuccessMsg(
          `قیمت دقیق کالا از المان [${parsed.sourceType}] به مبلغ ${formatPersianNumber(parsed.priceToman)} تومان استخراج و خودکار درج شد.`
        );
      }
    }
  };

  // Smart extraction from Digikala URL: Automatically extracts NON-DISCOUNTED price, title, image, and category!
  const handleExtractFromUrl = async (overrideUrl?: string) => {
    const targetUrl = overrideUrl || url;
    if (!targetUrl.trim() && !inspectSnippet.trim()) return;

    try {
      setIsExtracting(true);
      setExtractSuccessMsg(null);
      setExtractErrorMsg(null);
      setDiscountInfo(null);

      let extractedData: any = null;
      let diagnosticMsg = '';

      // Tier 1: Try current host (/api/track-url - works on local dev and Cloudflare Pages Edge Worker)
      try {
        const res = await fetch('/api/track-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url: targetUrl.trim(),
            inspectHtml: inspectSnippet.trim(),
          }),
        });

        const contentType = res.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const json = await res.json();
          if (json.success && json.data) {
            extractedData = json.data;
          } else if (json.error) {
            diagnosticMsg = json.error;
          }
        } else {
          diagnosticMsg = res.status === 404
            ? 'خطای ۴۰۴ در کلادفلر: فایل _worker.js در ریشه پوشه dist آپلود نشده است.'
            : `پاسخ غیرمنتظره از سرور کلادفلر (کد ${res.status})`;
        }
      } catch (backendErr: any) {
        diagnosticMsg = `عدم امکان ارتباط با سرور کلادفلر (${backendErr.message || 'NetworkError'})`;
      }

      // Tier 2: If on Cloudflare and local server (localhost:3000) is running on the computer, auto-bridge!
      if (!extractedData && !window.location.hostname.includes('localhost')) {
        try {
          const localRes = await fetch('http://localhost:3000/api/track-url', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              url: targetUrl.trim(),
              inspectHtml: inspectSnippet.trim(),
            }),
          });
          if (localRes.ok) {
            const localJson = await localRes.json();
            if (localJson.success && localJson.data) {
              extractedData = {
                ...localJson.data,
                source: `${localJson.data.source || 'استعلام سریع'} (متصل به سرور لوکال سیستم)`,
              };
            }
          }
        } catch {
          // localhost not active on user machine
        }
      }

      // Tier 3: Parse inspect snippet if provided
      if (!extractedData && inspectSnippet.trim()) {
        const parsed = extractPriceFromDigikalaInspect(inspectSnippet);
        if (parsed && parsed.priceToman > 0) {
          extractedData = {
            name: name || 'کالای استعلام‌شده',
            category,
            priceToman: parsed.priceToman,
            imageUrl: imageUrl || '',
            hasDiscount: false,
            source: 'استخراج مستقیم از کد اینسپکت',
            stockStatus: 'in_stock',
          };
        }
      }

      if (extractedData) {
        if (extractedData.priceToman > 0) {
          setPriceToman(extractedData.priceToman);
        }
        if (extractedData.name) {
          setName(extractedData.name);
        }
        if (extractedData.category) {
          setCategory(extractedData.category);
        }
        if (extractedData.imageUrl) {
          setImageUrl(extractedData.imageUrl);
        }

        setAutoFilled(true);

        if (extractedData.hasDiscount) {
          setDiscountInfo({
            hasDiscount: true,
            discountedPrice: extractedData.discountedPriceToman,
            discountPercent: extractedData.discountPercent,
          });
          setExtractSuccessMsg(
            `این کالا در دیجی‌کالا دارای ${extractedData.discountPercent || ''} تخفیف بود، اما بر اساس دستور شما قیمت اصلی و تخفیف‌نخورده (${formatPersianNumber(extractedData.priceToman)} تومان) درج گردید.`
          );
        } else {
          setDiscountInfo(null);
          setExtractSuccessMsg(
            extractedData.priceToman > 0
              ? `قیمت روز دیجی‌کالا (${formatPersianNumber(extractedData.priceToman)} تومان) با موفقیت استعلام و درج شد.`
              : 'مشخصات کالا دریافت شد (ناموجود در انبار).'
          );
        }
      } else {
        setExtractErrorMsg(
          diagnosticMsg ||
            'امکان استعلام خودکار فراهم نشد. لطفاً لینک کالا را بررسی کنید، یا کد اینسپکت دیجی‌کالا و قیمت را دستی وارد نمایید.'
        );
      }
    } catch (err: any) {
      console.error('Failed to extract product data', err);
      setExtractErrorMsg(`خطا در استعلام قیمت: ${err.message || 'لطفاً مجدداً تلاش کنید'}`);
    } finally {
      setIsExtracting(false);
    }
  };

  // Auto-trigger extraction when user pastes a complete Digikala product link or ID
  const handleUrlChange = (newUrl: string) => {
    setUrl(newUrl);
    const trimmed = newUrl.trim();
    if (
      (trimmed.includes('digikala.com') ||
        trimmed.includes('dkp-') ||
        trimmed.includes('product_id=') ||
        /^\d{4,10}$/.test(trimmed)) &&
      !isExtracting
    ) {
      handleExtractFromUrl(newUrl);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || priceToman <= 0) return;

    const newProdPayload = {
      id: `prod_${Date.now()}`,
      name: name.trim(),
      category,
      sourceUrl: url.trim(),
      imageUrl:
        imageUrl.trim() ||
        'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
      currentPriceToman: priceToman,
      lastPriceToman: priceToman,
      marginPercent: Number(marginPercent) || 0,
      customerQuoteToman: customerSellingPrice || priceToman,
      stockStatus: 'in_stock' as const,
      warranty: '',
      lastRefreshedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      notes: notes.trim(),
    };

    try {
      setIsSubmitting(true);
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProdPayload),
      });

      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const json = await res.json();
        if (json.success && json.product) {
          onProductAdded(json.product);
          onClose();
          return;
        }
      }

      // If backend was unreachable or non-JSON (e.g. static host), add directly
      onProductAdded(newProdPayload);
      onClose();
    } catch (err) {
      // In offline/static mode, still succeed
      onProductAdded(newProdPayload);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl space-y-6 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <span className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold">
              +
            </span>
            <div>
              <h3 className="font-bold text-white text-base sm:text-lg">
                افزودن کالا با استعلام قیمت اصلی دیجی‌کالا
              </h3>
              <p className="text-xs text-slate-400">
                در صورت وجود تخفیف در دیجی‌کالا، قیمت اصلی و تخفیف‌نخورده محاسبه می‌گردد
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="بستن پنجره"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Server Connection Status Banner */}
        <div className="flex items-center justify-between text-xs px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  serverStatus?.isOnline ? 'bg-emerald-400' : serverStatus ? 'bg-rose-400' : 'bg-indigo-400'
                }`}
              ></span>
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  serverStatus?.isOnline ? 'bg-emerald-500' : serverStatus ? 'bg-rose-500' : 'bg-indigo-500'
                }`}
              ></span>
            </span>
            <span className="text-slate-300 text-[11px]">
              {serverStatus
                ? serverStatus.text
                : 'محیط استعلام: ورکر لبه کلادفلر (Cloudflare Edge) و سرور لوکال سیستم'}
            </span>
          </div>

          <button
            type="button"
            onClick={checkServerHealth}
            disabled={isCheckingServer}
            className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition whitespace-nowrap"
          >
            <Activity className={`w-3.5 h-3.5 ${isCheckingServer ? 'animate-spin' : ''}`} />
            <span>{isCheckingServer ? 'در حال بررسی...' : 'تست اتصال سرور'}</span>
          </button>
        </div>

        {/* Step 1: URL input & Auto-fetch */}
        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-200">
                ۱. لینک کالای دیجی‌کالا (استخراج خودکار قیمت بدون تخفیف):
              </label>
              <span className="text-[11px] text-indigo-400 flex items-center gap-1">
                <Zap className="w-3 h-3" />
                <span>محاسبه قیمت پایه اصلی کالا</span>
              </span>
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <LinkIcon className="w-4 h-4 text-slate-500 absolute top-3 right-3" />
                <input
                  type="url"
                  value={url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  placeholder="https://www.digikala.com/product/dkp-..."
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 pr-9 pl-3 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>

              <button
                type="button"
                onClick={() => handleExtractFromUrl()}
                disabled={isExtracting || (!url.trim() && !inspectSnippet.trim())}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition active:scale-95 whitespace-nowrap"
              >
                <Search className={`w-3.5 h-3.5 ${isExtracting ? 'animate-spin' : ''}`} />
                <span>{isExtracting ? 'در حال استعلام قیمت اصلی...' : 'استعلام خودکار قیمت'}</span>
              </button>
            </div>
          </div>

          {/* Direct Inspect Element Paste (as fast fallback) */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>۲. یا الصاق مستقیم کد اینسپکت یا عدد قیمت:</span>
              </label>
              <span className="text-[10px] text-slate-400 font-mono">
                data-testid="price-no-discount"
              </span>
            </div>
            <textarea
              rows={2}
              value={inspectSnippet}
              onChange={(e) => handleInspectSnippetChange(e.target.value)}
              placeholder='کد کپی‌شده از اینسپکت دیجی‌کالا (مثلاً: <span data-testid="price-no-discount">۲,۳۵۰,۰۰۰</span>) یا قیمت...'
              className="w-full rounded-xl border border-indigo-900/60 bg-indigo-950/20 p-2.5 text-xs text-indigo-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono leading-relaxed resize-none"
            />
          </div>

          {/* Error Banner */}
          {extractErrorMsg && (
            <div className="text-xs text-rose-300 bg-rose-950/60 p-3 rounded-xl border border-rose-700/60 flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-semibold block">{extractErrorMsg}</span>
                <span className="text-[11px] text-slate-400 block">
                  می‌توانید کادر شماره ۲ بالا را با عدد قیمت یا کد اینسپکت دیجی‌کالا پر کنید، یا قیمت را مستقیماً در فرم زیر بنویسید.
                </span>
              </div>
            </div>
          )}

          {/* Success Banner */}
          {extractSuccessMsg && (
            <div className="text-xs text-emerald-300 bg-emerald-950/60 p-3 rounded-xl border border-emerald-700/60 flex items-start gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-semibold block">{extractSuccessMsg}</span>
                <div className="flex flex-wrap items-center gap-3 text-[11px]">
                  <span className="text-emerald-400 font-mono font-bold">
                    قیمت مبنای درج‌شده: {formatPersianNumber(priceToman)} تومان
                  </span>
                  {discountInfo?.discountedPrice ? (
                    <span className="text-slate-400 line-through font-mono">
                      قیمت تخفیف‌خورده نادیده‌گرفته: {formatPersianNumber(discountInfo.discountedPrice)} تومان
                    </span>
                  ) : null}
                </div>
              </div>
            </div>
          )}

          {/* Quick preset links including user's discounted product */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px] text-slate-400">
            <span>آزمایش سریع با نمونه‌ها:</span>
            {sampleLinks.map((sample, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setUrl(sample.url);
                  handleExtractFromUrl(sample.url);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs border transition ${
                  sample.title.includes('تخفیف')
                    ? 'bg-amber-950/50 border-amber-600/50 text-amber-300 hover:bg-amber-900/50'
                    : 'bg-slate-800 hover:bg-indigo-600/40 text-indigo-300 hover:text-white border-slate-700/60'
                }`}
              >
                {sample.title}
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Form (Warranty and Shop Cost removed) */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                نام کامل کالا:
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: ماوس بی سیم گیمینگ مدل T2"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">دسته‌بندی:</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-xs sm:text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="لوازم جانبی و گیمینگ">لوازم جانبی و گیمینگ (ماوس، کیبورد، هدست)</option>
                <option value="لپ‌تاپ و اولترابوک">لپ‌تاپ و اولترابوک</option>
                <option value="قطعات و ارتقا سیستم">قطعات و ارتقا سیستم (رم، SSD، گرافیک، CPU)</option>
                <option value="مانیتور و نمایشگر">مانیتور و نمایشگر</option>
                <option value="لوازم جانبی و قطعات">سایر لوازم و قطعات کامپیوتر</option>
                <option value="تعمیرات و خدمات سخت‌افزاری">تعمیرات و خدمات سخت‌افزاری</option>
              </select>
            </div>

            {/* Price field - Smart auto-filled */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-300">
                  قیمت اصلی مرجع (بدون تخفیف - تومان):
                </label>
                {priceToman > 0 && (
                  <span className="text-[11px] font-bold text-emerald-400 font-mono bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
                    {autoFilled ? '✓ استخراج هوشمند' : 'ثبت‌شده'}: {formatPersianNumber(priceToman)} تومان
                  </span>
                )}
              </div>
              <input
                type="number"
                required
                value={priceToman || ''}
                onChange={(e) => setPriceToman(Number(e.target.value))}
                placeholder="با زدن دکمه استعلام خودکار درج می‌شود"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>

            {/* Profit Margin % & Customer Selling Price Calculator */}
            <div className="sm:col-span-2 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-800/40 p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300">
                    <Percent className="w-4 h-4 text-indigo-400" />
                    <span>تعیین درصد سود فروشگاه و محاسبه خودکار قیمت فروش به مشتری:</span>
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    درصد سود دلخواه خود را وارد کنید یا از دکمه‌های سریع زیر انتخاب نمایید
                  </span>
                </div>

                {/* Quick margin percent buttons */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[3, 5, 8, 10, 12, 15, 20].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setMarginPercent(pct)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition active:scale-95 ${
                        marginPercent === pct
                          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/40 border border-indigo-500'
                          : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                      }`}
                    >
                      {toPersianDigits(pct)}٪
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/80">
                {/* 1. Custom Margin Input */}
                <div>
                  <label className="text-[11px] font-medium text-slate-300 block mb-1">
                    درصد سود اختصاصی شما:
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={marginPercent}
                      onChange={(e) => setMarginPercent(Number(e.target.value))}
                      placeholder="۱۰"
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 pr-3 pl-8 py-2 text-sm text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">٪</span>
                  </div>
                </div>

                {/* 2. Calculated Profit in Toman */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 flex flex-col justify-center">
                  <span className="text-[10px] text-slate-400 block">سود ریالی شما روی هر کالا:</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-sm sm:text-base font-bold text-indigo-300 font-mono">
                      +{formatPersianNumber(profitAmountToman)}
                    </span>
                    <span className="text-[10px] text-slate-400">تومان</span>
                  </div>
                </div>

                {/* 3. Final Selling Price to Customer (Hero) */}
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-950/60 to-teal-950/40 border border-emerald-700/60 flex flex-col justify-center">
                  <span className="text-[10px] text-emerald-300 font-semibold block">قیمت نهایی فروش به مشتری:</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="text-base sm:text-lg font-black text-emerald-400 font-mono tracking-tight">
                      {formatPersianNumber(customerSellingPrice)}
                    </span>
                    <span className="text-xs text-emerald-500 font-medium">تومان</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                آدرس تصویر کالا (استخراج خودکار از دیجی‌کالا):
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://dkstatics-public.digikala.com/..."
                  className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
                {imageUrl && (
                  <img
                    src={imageUrl}
                    alt="پیش‌نمایش"
                    className="w-9 h-9 rounded-lg object-cover border border-slate-700"
                  />
                )}
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                یادداشت‌های مغازه (اختیاری):
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="توضیحات اختصاصی برای موجودی انبار، خدمات سخت‌افزاری یا قطعات..."
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2 text-xs sm:text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-medium transition"
            >
              انصراف
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !name.trim() || priceToman <= 0}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-emerald-950/40 transition active:scale-95"
            >
              {isSubmitting ? 'در حال ثبت...' : 'ذخیره کالا و پایش قیمت اصلی'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
