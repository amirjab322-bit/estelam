import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { FIXED_SCHEDULE_HOURS, getNextScheduledRefresh } from './src/utils/schedule.ts';
import { gregorianToJalali, toPersianDigits, formatPersianNumber } from './src/utils/jalali.ts';
import { extractPriceFromDigikalaInspect } from './src/utils/digikalaScraper.ts';
import { scrapeLiveDigikalaProduct } from './src/utils/liveScraper.ts';
import { scrapeProductUniversal } from './src/utils/universalScraper.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Enable CORS and Private Network Access for Cloudflare Pages integration
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Private-Network', 'true');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

const DATA_DIR = path.join(__dirname, 'data', 'products');

// Ensure base data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  sourceUrl: string;
  imageUrl: string;
  currentPriceToman: number;
  lastPriceToman: number;
  shopCostToman?: number;
  marginPercent: number;
  customerQuoteToman: number;
  stockStatus: 'in_stock' | 'out_of_stock' | 'call';
  warranty: string;
  lastRefreshedAt: string;
  createdAt: string;
  notes: string;
}

export interface PriceHistoryItem {
  timestamp: string;
  jalaliDate: string;
  jalaliTime: string;
  priceToman: number;
  customerQuoteToman: number;
  source: string;
  changePercent?: number;
}

// Helper to format Jalali date string
function getJalaliDateString(d: Date): { date: string; time: string } {
  const j = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  const date = `${toPersianDigits(j.jy)}/${toPersianDigits(String(j.jm).padStart(2, '0'))}/${toPersianDigits(String(j.jd).padStart(2, '0'))}`;
  const time = `${toPersianDigits(String(d.getHours()).padStart(2, '0'))}:${toPersianDigits(String(d.getMinutes()).padStart(2, '0'))}`;
  return { date, time };
}

// Seed Initial Products if empty
function initializeSeedData() {
  const existing = fs.readdirSync(DATA_DIR);
  if (existing.length > 0) return;

  const seeds: { product: ProductItem; basePrice: number; variance: number[] }[] = [
    {
      product: {
        id: 'prod_asus_tuf_f15',
        name: 'لپ‌تاپ ۱۵.۶ اینچی ایسوس TUF Gaming F15 FX507 (Core i7 / 16GB / 512GB / RTX 4060)',
        category: 'لپ‌تاپ و اولترابوک',
        sourceUrl: 'https://www.digikala.com/product/dkp-13840212/asus-tuf-gaming-f15-fx507/',
        imageUrl: 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=600&q=80',
        currentPriceToman: 64900000,
        lastPriceToman: 63500000,
        shopCostToman: 59800000,
        marginPercent: 8,
        customerQuoteToman: 70100000,
        stockStatus: 'in_stock',
        warranty: 'گارانتی ۱۸ ماهه یکپارچه حامی / آواژنگ',
        lastRefreshedAt: new Date().toISOString(),
        createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
        notes: 'مناسب گیمینگ و مهندسی سنگین، نوسان دلاری بالا، بررسی قیمت روز الزامی است',
      },
      basePrice: 61000000,
      variance: [0, 500000, -300000, 1200000, 800000, 1500000, 200000, 1000000],
    },
    {
      product: {
        id: 'prod_logitech_g502',
        name: 'ماوس مخصوص بازی لاجیتک مدل G502 HERO با حسگر HERO 25K',
        category: 'لوازم جانبی و گیمینگ',
        sourceUrl: 'https://www.digikala.com/product/dkp-2384729/logitech-g502-hero/',
        imageUrl: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=600&q=80',
        currentPriceToman: 2890000,
        lastPriceToman: 2790000,
        shopCostToman: 2350000,
        marginPercent: 12,
        customerQuoteToman: 3250000,
        stockStatus: 'in_stock',
        warranty: '۲۴ ماه گارانتی پانا / اسپیرو',
        lastRefreshedAt: new Date().toISOString(),
        createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
        notes: 'پرفروش‌ترین ماوس مغازه، در صورت خرید تعداد تخفیف همکار لحاظ شود',
      },
      basePrice: 2450000,
      variance: [0, 40000, 90000, 30000, 110000, 80000, 90000],
    },
    {
      product: {
        id: 'prod_samsung_ssd_980pro',
        name: 'حافظه اس‌اس‌دی سامسونگ مدل 980 PRO PCIe 4.0 NVMe M.2 ظرفیت 1 ترابایت',
        category: 'قطعات و ارتقا سیستم',
        sourceUrl: 'https://www.digikala.com/product/dkp-4820194/samsung-980-pro-nvme-1tb/',
        imageUrl: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=600&q=80',
        currentPriceToman: 5450000,
        lastPriceToman: 5300000,
        shopCostToman: 4700000,
        marginPercent: 10,
        customerQuoteToman: 6000000,
        stockStatus: 'in_stock',
        warranty: 'گارانتی ۵ ساله ماتریکس / الماس ایران',
        lastRefreshedAt: new Date().toISOString(),
        createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
        notes: 'قطعه اصلی برای ارتقای لپ‌تاپ‌های بخش تعمیرات مغازه',
      },
      basePrice: 4800000,
      variance: [0, 100000, -50000, 200000, 150000, 250000],
    },
    {
      product: {
        id: 'prod_xiaomi_monitor_27',
        name: 'مانیتور گیمینگ ۲۷ اینچ شیائومی مدل Redmi G27 با نرخ نوسازی 165Hz IPS',
        category: 'مانیتور و نمایشگر',
        sourceUrl: 'https://www.digikala.com/product/dkp-9302148/xiaomi-redmi-g27-165hz/',
        imageUrl: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=600&q=80',
        currentPriceToman: 9800000,
        lastPriceToman: 9400000,
        shopCostToman: 8500000,
        marginPercent: 9,
        customerQuoteToman: 10700000,
        stockStatus: 'in_stock',
        warranty: '۱۸ ماه گارانتی شرکتی می ایران',
        lastRefreshedAt: new Date().toISOString(),
        createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000).toISOString(),
        notes: 'فوق‌العاده برای ستاپ‌های برنامه‌نویسی و بازی، نمایش در ویترین مغازه',
      },
      basePrice: 8900000,
      variance: [0, 200000, 150000, 300000, -100000, 350000],
    },
  ];

  seeds.forEach(({ product, basePrice, variance }) => {
    const prodDir = path.join(DATA_DIR, product.id);
    if (!fs.existsSync(prodDir)) {
      fs.mkdirSync(prodDir, { recursive: true });
    }

    fs.writeFileSync(path.join(prodDir, 'product.json'), JSON.stringify(product, null, 2));

    // Generate historical price logs across past 14 days
    const history: PriceHistoryItem[] = [];
    let currentP = basePrice;
    const now = Date.now();

    const stepCount = variance.length;
    let varIdx = 0;
    for (let day = 14; day >= 0; day--) {
      // 2 snapshots per day (e.g. 09:00 and 15:00)
      const times = [9, 15];
      for (const hr of times) {
        const timestampDate = new Date(now - day * 24 * 3600 * 1000);
        timestampDate.setHours(hr, 0, 0, 0);

        if (timestampDate.getTime() > now) continue;

        const v = variance[varIdx % stepCount] || 0;
        varIdx++;
        currentP = basePrice + v;
        const custQuote = Math.round((currentP * (1 + product.marginPercent / 100)) / 10000) * 10000;

        const { date, time } = getJalaliDateString(timestampDate);
        history.push({
          timestamp: timestampDate.toISOString(),
          jalaliDate: date,
          jalaliTime: time,
          priceToman: currentP,
          customerQuoteToman: custQuote,
          source: hr === 9 ? 'پایش صبحگاه' : 'پایش عصرانه',
        });
      }
    }

    // Set the latest historical price to currentPriceToman
    if (history.length > 0) {
      history[history.length - 1].priceToman = product.currentPriceToman;
      history[history.length - 1].customerQuoteToman = product.customerQuoteToman;
    }

    fs.writeFileSync(path.join(prodDir, 'history.json'), JSON.stringify(history, null, 2));
  });
}

initializeSeedData();

// GET all products
app.get('/api/products', (req, res) => {
  try {
    const productDirs = fs.readdirSync(DATA_DIR);
    const products: ProductItem[] = [];

    for (const dir of productDirs) {
      const prodFile = path.join(DATA_DIR, dir, 'product.json');
      if (fs.existsSync(prodFile)) {
        try {
          const data = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
          products.push(data);
        } catch (e) {
          console.error('Error reading product:', prodFile, e);
        }
      }
    }

    res.json({ success: true, products });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET product history
app.get('/api/products/:id/history', (req, res) => {
  try {
    const { id } = req.params;
    const historyFile = path.join(DATA_DIR, id, 'history.json');

    if (!fs.existsSync(historyFile)) {
      return res.status(404).json({ success: false, error: 'تاریخچه‌ای برای این محصول یافت نشد' });
    }

    const history: PriceHistoryItem[] = JSON.parse(fs.readFileSync(historyFile, 'utf-8'));
    res.json({ success: true, history });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST create product
app.post('/api/products', (req, res) => {
  try {
    const body = req.body;
    const id = body.id || `prod_${Date.now()}`;
    const prodDir = path.join(DATA_DIR, id);

    if (!fs.existsSync(prodDir)) {
      fs.mkdirSync(prodDir, { recursive: true });
    }

    const margin = Number(body.marginPercent) || 8;
    const currentPrice = Number(body.currentPriceToman) || 0;
    const customerQuote =
      body.customerQuoteToman ||
      Math.ceil((currentPrice * (1 + margin / 100)) / 5000) * 5000;

    const newProduct: ProductItem = {
      id,
      name: body.name || 'محصول بدون نام',
      category: body.category || 'عمومی',
      sourceUrl: body.sourceUrl || '',
      imageUrl:
        body.imageUrl ||
        'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
      currentPriceToman: currentPrice,
      lastPriceToman: currentPrice,
      shopCostToman: Number(body.shopCostToman) || Math.round(currentPrice * 0.92),
      marginPercent: margin,
      customerQuoteToman: customerQuote,
      stockStatus: body.stockStatus || 'in_stock',
      warranty: body.warranty || '',
      lastRefreshedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      notes: body.notes || '',
    };

    fs.writeFileSync(path.join(prodDir, 'product.json'), JSON.stringify(newProduct, null, 2));

    // Initialize first history record
    const { date, time } = getJalaliDateString(new Date());
    const initialHistory: PriceHistoryItem[] = [
      {
        timestamp: new Date().toISOString(),
        jalaliDate: date,
        jalaliTime: time,
        priceToman: currentPrice,
        customerQuoteToman: customerQuote,
        source: 'ثبت اولیه',
      },
    ];

    fs.writeFileSync(path.join(prodDir, 'history.json'), JSON.stringify(initialHistory, null, 2));

    res.json({ success: true, product: newProduct });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// PUT update product
app.put('/api/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    const prodDir = path.join(DATA_DIR, id);
    const prodFile = path.join(prodDir, 'product.json');

    if (!fs.existsSync(prodFile)) {
      return res.status(404).json({ success: false, error: 'محصول یافت نشد' });
    }

    const currentData: ProductItem = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
    const updated = { ...currentData, ...req.body, id };

    fs.writeFileSync(prodFile, JSON.stringify(updated, null, 2));
    res.json({ success: true, product: updated });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// DELETE product: Completely wipe product folder, history and files as requested!
app.delete('/api/products/:id', (req, res) => {
  try {
    const { id } = req.params;
    const prodDir = path.join(DATA_DIR, id);

    if (fs.existsSync(prodDir)) {
      fs.rmSync(prodDir, { recursive: true, force: true });
      return res.json({ success: true, message: `محصول و پوشه تاریخچه آن کاملاً حذف شد: ${id}` });
    } else {
      return res.status(404).json({ success: false, error: 'پوشه محصول یافت نشد' });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET Track URL health check endpoint
app.get('/api/track-url', (req, res) => {
  res.json({
    success: true,
    status: 'online',
    message: 'سرور محلی استعلام (server.ts) با موفقیت فعال و آماده پاسخگویی است',
    environment: 'Node.js Local Express',
    timestamp: new Date().toISOString(),
  });
});

// Track URL & Inspect Snippet endpoint
app.post('/api/track-url', async (req, res) => {
  try {
    const { url, inspectHtml } = req.body;

    // 1. Check if user provided an inspect element snippet (e.g. from Chrome DevTools)
    if (inspectHtml && typeof inspectHtml === 'string' && inspectHtml.trim()) {
      const parsedInspect = extractPriceFromDigikalaInspect(inspectHtml);
      if (parsedInspect) {
        return res.json({
          success: true,
          data: {
            name: req.body.name || 'کالای استعلام‌شده از دیجی‌کالا',
            priceToman: parsedInspect.priceToman,
            imageUrl:
              req.body.imageUrl ||
              'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80',
            warranty: 'گارانتی معتبر شرکتی',
            source: `استخراج مستقیم از المان [${parsedInspect.sourceType}]`,
            stockStatus: 'in_stock',
          },
        });
      }
    }

    if (!url) {
      return res.status(400).json({ success: false, error: 'آدرس اینترنتی یا متن اینسپکت وارد نشده است' });
    }

    // 2. Digikala Live URL Scraper via High-Speed Universal Microservice Engine
    const cleanUrl = url.trim();
    if (cleanUrl.includes('digikala.com') || cleanUrl.includes('dkp-') || /^\d{4,10}$/.test(cleanUrl)) {
      console.log(`[Scraper] Starting live query for Digikala URL/ID: ${cleanUrl}`);
      try {
        let liveData = await scrapeProductUniversal(cleanUrl);
        if (!liveData) {
          liveData = await scrapeLiveDigikalaProduct(cleanUrl);
        }
        if (liveData && (liveData.priceToman > 0 || liveData.stockStatus === 'out_of_stock')) {
          console.log(`[Scraper] Successfully extracted data: ${liveData.priceToman} Toman for ${liveData.name}`);
          return res.json({
            success: true,
            data: {
              ...liveData,
              warranty: '',
            },
          });
        }
      } catch (err: any) {
        console.warn(`[Scraper] Live scrape warning:`, err.message);
      }
    }

    // Fallback: If URL contains tech keywords, extract recognizable metadata
    let parsedName = 'قطعه / کالای سخت‌افزاری کامپیوتر';
    let defaultPrice = 0;
    let img = 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80';
    let cat = 'لوازم جانبی و قطعات';

    if (url.includes('laptop') || url.includes('لپ-تاپ')) {
      parsedName = 'لپ‌تاپ تخصصی کارشناسی شده';
      cat = 'لپ‌تاپ و اولترابوک';
      img = 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=600&q=80';
    } else if (url.includes('mouse') || url.includes('ماوس')) {
      parsedName = 'ماوس اپتیکال / گیمینگ';
      cat = 'لوازم جانبی و گیمینگ';
      img = 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=600&q=80';
    } else if (url.includes('ssd') || url.includes('اس-اس-دی')) {
      parsedName = 'حافظه پرسرعت SSD NVMe M.2';
      cat = 'قطعات و ارتقا سیستم';
      img = 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=600&q=80';
    }

    return res.json({
      success: true,
      data: {
        name: parsedName,
        category: cat,
        priceToman: defaultPrice,
        imageUrl: img,
        warranty: '',
        source: 'استعلام آنلاین',
        stockStatus: 'in_stock',
      },
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Sync a single product with Digikala live price (strictly genuine reference price - ZERO artificial fluctuation)
async function syncProductPriceWithStore(
  prod: ProductItem,
  sourceTag: string
): Promise<{ product: ProductItem; priceChanged: boolean; message: string }> {
  const now = new Date();
  const { date, time } = getJalaliDateString(now);
  const prodDir = path.join(DATA_DIR, prod.id);
  const prodFile = path.join(prodDir, 'product.json');
  const historyFile = path.join(prodDir, 'history.json');

  const oldPrice = prod.currentPriceToman;
  let realPrice = prod.currentPriceToman;
  let source = sourceTag;
  let isLiveScraped = false;

  // If product has a sourceUrl from Digikala, fetch its real live price from [data-testid="price-final"]
  if (prod.sourceUrl && (prod.sourceUrl.includes('digikala.com') || prod.sourceUrl.includes('dkp-'))) {
    try {
      let scraped = await scrapeProductUniversal(prod.sourceUrl);
      if (!scraped) {
        scraped = await scrapeLiveDigikalaProduct(prod.sourceUrl);
      }
      if (scraped && scraped.priceToman > 0) {
        realPrice = scraped.priceToman;
        source = scraped.hasDiscount
          ? 'استعلام قیمت اصلی و بدون تخفیف دیجی‌کالا [data-testid="price-no-discount"]'
          : 'استعلام مستقیم دیجی‌کالا [data-testid="price-final"]';
        isLiveScraped = true;

        if (scraped.imageUrl && (!prod.imageUrl || prod.imageUrl.includes('unsplash'))) {
          prod.imageUrl = scraped.imageUrl;
        }
        if (scraped.name && (!prod.name || prod.name === 'محصول بدون نام' || prod.name === 'کالای دیجی‌کالا')) {
          prod.name = scraped.name;
        }
      }
    } catch (err: any) {
      console.warn(`[Sync] Live scrape warning for ${prod.id}:`, err.message);
    }
  }

  const priceChanged = realPrice !== oldPrice;

  // Set reference price strictly to realPrice
  prod.currentPriceToman = realPrice;
  if (priceChanged) {
    prod.lastPriceToman = oldPrice;
  } else {
    // Exact same price on Digikala: difference is 0% (constant, no fake fluctuations)
    prod.lastPriceToman = realPrice;
  }

  const margin = prod.marginPercent || 8;
  const newCustomerQuote = Math.ceil((realPrice * (1 + margin / 100)) / 5000) * 5000;
  prod.customerQuoteToman = newCustomerQuote;
  prod.lastRefreshedAt = now.toISOString();

  fs.writeFileSync(prodFile, JSON.stringify(prod, null, 2));

  // Only record in history if:
  // 1) History is completely empty
  // 2) The reference price on Digikala actually changed compared to the last recorded entry
  let history: PriceHistoryItem[] = [];
  if (fs.existsSync(historyFile)) {
    try {
      history = JSON.parse(fs.readFileSync(historyFile, 'utf-8'));
    } catch {
      history = [];
    }
  }

  const lastEntry = history.length > 0 ? history[history.length - 1] : null;

  if (history.length === 0 || (lastEntry && lastEntry.priceToman !== realPrice)) {
    const changePercent =
      lastEntry && lastEntry.priceToman > 0
        ? Number((((realPrice - lastEntry.priceToman) / lastEntry.priceToman) * 100).toFixed(1))
        : 0;

    history.push({
      timestamp: now.toISOString(),
      jalaliDate: date,
      jalaliTime: time,
      priceToman: realPrice,
      customerQuoteToman: newCustomerQuote,
      source,
      changePercent,
    });
    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
  }

  const message = priceChanged
    ? `قیمت کالا «${prod.name}» از ${formatPersianNumber(oldPrice)} به ${formatPersianNumber(realPrice)} تومان در دیجی‌کالا تغییر یافت`
    : `قیمت روز کالا «${prod.name}» دقیقاً ${formatPersianNumber(realPrice)} تومان استعلام شد (مطابق دیجی‌کالا بدون نوسان ساختگی)`;

  return { product: prod, priceChanged, message };
}

// Refresh all products price directly from Digikala (NO artificial fluctuation)
app.post('/api/products/refresh-all', async (req, res) => {
  try {
    const productDirs = fs.readdirSync(DATA_DIR);
    const updatedProducts: ProductItem[] = [];
    let changedCount = 0;

    for (const dir of productDirs) {
      const prodDir = path.join(DATA_DIR, dir);
      const prodFile = path.join(prodDir, 'product.json');

      if (fs.existsSync(prodFile)) {
        try {
          const prod: ProductItem = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
          const result = await syncProductPriceWithStore(
            prod,
            req.body.isScheduled ? 'پایش خودکار ۳ ساعته' : 'استعلام واقعی دیجی‌کالا'
          );
          if (result.priceChanged) changedCount++;
          updatedProducts.push(result.product);
        } catch (e) {
          console.error('Error refreshing product:', prodFile, e);
        }
      }
    }

    const message =
      changedCount > 0
        ? `${toPersianDigits(updatedProducts.length)} کالا استعلام شدند (${toPersianDigits(changedCount)} کالا تغییر قیمت واقعی در دیجی‌کالا داشتند)`
        : `${toPersianDigits(updatedProducts.length)} کالا مستقیماً از دیجی‌کالا استعلام شدند؛ قیمت روز مرجع دقیقاً تطبیق داده شد (بدون نوسان ساختگی)`;

    res.json({
      success: true,
      message,
      products: updatedProducts,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Refresh a single specific product from Digikala
app.post('/api/products/:id/refresh', async (req, res) => {
  try {
    const { id } = req.params;
    const prodDir = path.join(DATA_DIR, id);
    const prodFile = path.join(prodDir, 'product.json');

    if (!fs.existsSync(prodFile)) {
      return res.status(404).json({ success: false, error: 'محصول یافت نشد' });
    }

    const prod: ProductItem = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
    const result = await syncProductPriceWithStore(prod, 'استعلام مستقیم دیجی‌کالا');

    res.json({
      success: true,
      message: result.message,
      product: result.product,
      priceChanged: result.priceChanged,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// SIMULATION & TEST RUNNER:
// Allows testing and verifying that price changes on the reference site immediately update
// product price, customer quote, price history, and trend graphs!
app.post('/api/simulation/test-price-change', async (req, res) => {
  try {
    let { productId, newPriceToman, percentChange } = req.body;

    const productDirs = fs.readdirSync(DATA_DIR);
    if (productDirs.length === 0) {
      return res.status(400).json({ success: false, error: 'هیچ کالایی برای آزمون شبیه‌سازی یافت نشد' });
    }

    if (!productId || !fs.existsSync(path.join(DATA_DIR, productId, 'product.json'))) {
      productId = productDirs[0];
    }

    const prodDir = path.join(DATA_DIR, productId);
    const prodFile = path.join(prodDir, 'product.json');
    const historyFile = path.join(prodDir, 'history.json');

    const currentProd: ProductItem = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
    const oldPrice = currentProd.currentPriceToman;
    const oldQuote = currentProd.customerQuoteToman;

    // Calculate target new price
    let targetPrice = Number(newPriceToman);
    if (!targetPrice || targetPrice <= 0) {
      const pct = Number(percentChange) || 5;
      targetPrice = Math.round(oldPrice * (1 + pct / 100));
    }

    const now = new Date();
    const { date, time } = getJalaliDateString(now);

    const margin = currentProd.marginPercent || 8;
    const newCustomerQuote = Math.ceil((targetPrice * (1 + margin / 100)) / 5000) * 5000;

    // Update product object
    currentProd.lastPriceToman = oldPrice;
    currentProd.currentPriceToman = targetPrice;
    currentProd.customerQuoteToman = newCustomerQuote;
    currentProd.lastRefreshedAt = now.toISOString();

    fs.writeFileSync(prodFile, JSON.stringify(currentProd, null, 2));

    // Append to history
    let history: PriceHistoryItem[] = [];
    if (fs.existsSync(historyFile)) {
      try {
        history = JSON.parse(fs.readFileSync(historyFile, 'utf-8'));
      } catch {
        history = [];
      }
    }

    const priceDiff = targetPrice - oldPrice;
    const actualPercent = Number(((priceDiff / oldPrice) * 100).toFixed(1));

    const newHistoryItem: PriceHistoryItem = {
      timestamp: now.toISOString(),
      jalaliDate: date,
      jalaliTime: time,
      priceToman: targetPrice,
      customerQuoteToman: newCustomerQuote,
      source: 'شبیه‌سازی تغییر قیمت در سایت مرجع (آزمون صحت عملکرد)',
      changePercent: actualPercent,
    };

    history.push(newHistoryItem);
    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));

    return res.json({
      success: true,
      message: `آزمون شبیه‌سازی با موفقیت انجام شد: قیمت «${currentProd.name}» با موفقیت بروزرسانی شد.`,
      testReport: {
        product: currentProd,
        oldPrice,
        newPrice: targetPrice,
        priceDiff,
        percentChange: actualPercent,
        oldQuote,
        newQuote: newCustomerQuote,
        historyCount: history.length,
        jalaliTimestamp: `${date} - ${time}`,
        verificationChecks: {
          productUpdated: true,
          quoteRecalculated: true,
          historyRecorded: true,
          databaseVerified: true,
        },
      },
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Scheduler status & execution logic
let lastAutoSyncTime: string | null = null;
let lastSyncReport: { hour: number; totalChecked: number; priceChangedCount: number; timestamp: string } | null = null;

// Function to run the fixed 3-hour automatic synchronization
async function executeThreeHourAutoSync(triggerSource: string = 'پایش خودکار ۳ ساعته') {
  const now = new Date();
  lastAutoSyncTime = now.toISOString();
  console.log(`[Scheduler] 3-Hour Sync Started (${triggerSource}) at ${now.toLocaleTimeString()}`);

  let changedCount = 0;
  let totalCount = 0;
  try {
    const productDirs = fs.readdirSync(DATA_DIR);
    for (const dir of productDirs) {
      const prodDir = path.join(DATA_DIR, dir);
      const prodFile = path.join(prodDir, 'product.json');

      if (fs.existsSync(prodFile)) {
        try {
          totalCount++;
          const prod: ProductItem = JSON.parse(fs.readFileSync(prodFile, 'utf-8'));
          const res = await syncProductPriceWithStore(prod, triggerSource);
          if (res.priceChanged) changedCount++;
        } catch (e) {
          console.error('[Scheduler Error for prod]', dir, e);
        }
      }
    }

    lastSyncReport = {
      hour: now.getHours(),
      totalChecked: totalCount,
      priceChangedCount: changedCount,
      timestamp: now.toISOString(),
    };
    console.log(`[Scheduler] 3-Hour Sync Complete: ${totalCount} checked, ${changedCount} price(s) updated.`);
  } catch (e) {
    console.error('[Scheduler Error]', e);
  }

  return { totalCount, changedCount, lastSyncReport };
}

// Scheduler status endpoint
app.get('/api/scheduler/status', (req, res) => {
  const next = getNextScheduledRefresh();
  res.json({
    success: true,
    active: true,
    scheduleInterval: 'هر ۳ ساعت یکبار در ۸ نوبت ثابت روزانه',
    fixedScheduleHours: FIXED_SCHEDULE_HOURS,
    nextScheduledTime: next.formattedTargetTime,
    remainingMinutes: next.remainingMinutes,
    lastAutoSyncTime,
    lastSyncReport,
  });
});

// Manual trigger for the 3-hour schedule test
app.post('/api/scheduler/trigger-now', async (req, res) => {
  try {
    const result = await executeThreeHourAutoSync('استعلام دستی نوبت ۳ ساعته');
    res.json({
      success: true,
      message: `پایش ۳ ساعته با موفقیت انجام شد: ${result.totalCount} کالا بررسی شد.`,
      result,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// In-process Background 3-hour cron scheduler check
let lastCheckedHour = -1;
setInterval(async () => {
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();

  // If current hour is in FIXED_SCHEDULE_HOURS and it's within the first 5 minutes of the hour
  if (FIXED_SCHEDULE_HOURS.includes(currentHour) && currentMinute < 5 && lastCheckedHour !== currentHour) {
    lastCheckedHour = currentHour;
    await executeThreeHourAutoSync('پایش خودکار ۳ ساعته');
  }
}, 20000); // Check every 20 seconds

// Mount Vite middleware in development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Computer Shop Price Tracker Server running on http://localhost:${PORT}`);
  });
}

startServer();
